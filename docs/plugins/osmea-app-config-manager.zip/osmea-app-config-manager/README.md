# OSMEA App Config Manager

WordPress plugin - Manage Flutter mobile app configuration file (`app_config.json`) from WordPress admin panel.

## Features

- ✅ Edit JSON configuration from WordPress admin panel
- ✅ Provide configuration to mobile app via REST API endpoint
- ✅ JSON formatting and validation
- ✅ Import/export configuration
- ✅ Reset to default configuration
- ✅ Real-time JSON validation

## Installation

1. Copy the plugin folder to WordPress `wp-content/plugins/` directory:
   ```bash
   cp -r osmea-app-config-manager /path/to/wordpress/wp-content/plugins/
   ```

2. Go to **Plugins** page in WordPress admin panel

3. Activate **OSMEA App Config Manager** plugin

4. Edit configuration from **Settings > OSMEA App Config** menu

## Usage

### Admin Panel

1. Go to **Settings > OSMEA App Config** page in WordPress admin panel
2. Edit JSON configuration
3. Use **Format JSON** button to format JSON properly
4. Click **Save Configuration** button

### REST API

The plugin provides REST API endpoint for your mobile app to fetch configuration:

**GET Endpoint:**
```
GET /wp-json/osmea/v1/app-config
```

**Example Usage:**
```bash
curl https://your-site.com/wp-json/osmea/v1/app-config
```

**POST Endpoint (Admin permission required):**
```
POST /wp-json/osmea/v1/app-config
Content-Type: application/json

{
  "app_settings": {
    "app_name": "My App"
  }
}
```

### Usage in Flutter App

You can fetch configuration in your Flutter app like this:

```dart
import 'package:http/http.dart' as http;
import 'dart:convert';

Future<Map<String, dynamic>> fetchAppConfig() async {
  final response = await http.get(
    Uri.parse('https://your-site.com/wp-json/osmea/v1/app-config'),
  );
  
  if (response.statusCode == 200) {
    return json.decode(response.body);
  } else {
    throw Exception('Failed to load configuration');
  }
}
```

## File Structure

```
osmea-app-config-manager/
├── osmea-app-config-manager.php  # Main plugin file
├── default-config.json            # Default configuration
├── assets/
│   ├── admin.css                  # Admin panel styles
│   └── admin.js                   # Admin panel JavaScript
└── README.md                      # This file
```

## Feature Details

### JSON Validation
- Real-time JSON validation
- User notification with error messages
- Valid/invalid status indicator

### Formatting
- One-click JSON formatting
- Readable and organized JSON output

### Import/Export
- Export as JSON file
- Import from JSON file
- Backup and restore support

### REST API
- Public GET endpoint (for mobile app)
- Protected POST endpoint (for admin)
- WordPress REST API standards compliant

## Security

- GET endpoint is public (for mobile app access)
- POST endpoint only for users with `manage_options` capability
- JSON validation and sanitization
- WordPress nonce verification

## Requirements

- WordPress 5.0 or higher
- PHP 7.4 or higher
- JSON extension (usually included by default in PHP)

## Troubleshooting

### Invalid JSON Error
- Check JSON format
- Use **Format JSON** button
- Check quotation marks

### REST API Not Accessible
- Make sure permalink structure is active
- Ensure `.htaccess` file is writable
- Check that WordPress REST API is active

### Configuration Not Saving
- Check WordPress database write permissions
- Check PHP error logs
- Check plugin permissions

## License

GPL v2 or later

## Support

You can use GitHub Issues for questions:
https://github.com/masterfabric-mobile/osmea

## Changelog

### 1.0.0
- Initial release
- Admin panel interface
- REST API endpoints
- JSON validation and formatting
- Import/export features
