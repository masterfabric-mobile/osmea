# Installation Instructions

## Quick Installation

### 1. Install Plugin

**Method 1: Manual Installation**
```bash
# Copy plugin folder to WordPress plugins directory
cd /path/to/wordpress/wp-content/plugins/
cp -r /path/to/osmea-app-config-manager ./
```

**Method 2: Upload as ZIP**
1. Compress `osmea-app-config-manager` folder as ZIP
2. In WordPress admin panel, go to **Plugins > Add New > Upload Plugin**
3. Select ZIP file and upload

### 2. Activate Plugin

1. Go to **Plugins** page in WordPress admin panel
2. Find **OSMEA App Config Manager** plugin
3. Click **Activate** button

### 3. Initial Configuration

1. Go to **Settings > OSMEA App Config** menu
2. Default configuration will be loaded automatically
3. Edit configuration according to your needs
4. Click **Save Configuration** button

## Test REST API Endpoint

After installation, test that REST API endpoint is working:

```bash
# Test from terminal
curl https://your-site.com/wp-json/osmea/v1/app-config

# Or from browser
https://your-site.com/wp-json/osmea/v1/app-config
```

A successful response should return configuration in JSON format.

## Flutter App Integration

### 1. Set API URL

Update API URL in `app_config.json` file:

```json
{
  "api_configuration": {
    "base_url": "https://your-wordpress-site.com/wp-json/osmea/v1"
  }
}
```

### 2. Fetch Configuration

To fetch configuration in your Flutter app:

```dart
import 'package:http/http.dart' as http;
import 'dart:convert';

class ConfigService {
  static Future<Map<String, dynamic>> fetchConfig(String baseUrl) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/app-config'),
        headers: {
          'Content-Type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to load configuration: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error loading configuration: $e');
    }
  }
}
```

### 3. Load on App Startup

```dart
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Fetch configuration from WordPress
  final config = await ConfigService.fetchConfig(
    'https://your-wordpress-site.com/wp-json/osmea/v1'
  );
  
  // Apply configuration to app
  runApp(MyApp(config: config));
}
```

## Troubleshooting

### Plugin Cannot Be Activated

- Make sure your PHP version is 7.4 or higher
- Make sure your WordPress version is 5.0 or higher
- Check PHP error logs

### REST API Not Working

1. **Check Permalink Structure:**
   - Go to **Settings > Permalinks** page
   - Select any structure and save (not default "Plain")

2. **Check .htaccess File:**
   - Make sure `.htaccess` file is writable
   - Ensure WordPress can update the file

3. **Test REST API:**
   ```bash
   curl https://your-site.com/wp-json/
   ```
   This command shows that WordPress REST API is working.

### JSON Not Saving

- Check WordPress database connection
- Check write permissions to `wp_options` table
- Increase PHP `max_input_vars` value (for very large JSON files)

## Update

To update the plugin:

1. Backup old plugin folder
2. Install new version
3. Configuration is automatically preserved (stored in database)

## Backup

To backup your configuration:

1. Click **Export** button in admin panel
2. JSON file will be downloaded
3. Store this file in a safe place

To restore:

1. Click **Import** button
2. Select the JSON file you backed up
3. Configuration will be loaded automatically
