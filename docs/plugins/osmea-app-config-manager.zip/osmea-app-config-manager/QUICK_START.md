# Quick Start Guide

## 📥 How to Download and Install

### Step 1: Get the Plugin Files

The plugin is located at:
```
docs/plugins/osmea-app-config-manager/
```

**Option A: From GitHub Repository**
1. Navigate to the repository: `https://github.com/masterfabric-mobile/osmea`
2. Go to `docs/plugins/osmea-app-config-manager/` folder
3. Download the entire folder

**Option B: From Local Project**
If you have the project locally:
```bash
cd /Users/melihalakabak/Documents/GitHub/osmea/docs/plugins/
# The osmea-app-config-manager folder is ready to use
```

### Step 2: Create ZIP File (for WordPress Upload)

1. **On macOS:**
   - Right-click on `osmea-app-config-manager` folder
   - Select "Compress osmea-app-config-manager"
   - A ZIP file will be created

2. **On Windows:**
   - Right-click on `osmea-app-config-manager` folder
   - Select "Send to > Compressed (zipped) folder"

3. **On Linux:**
   ```bash
   cd docs/plugins/
   zip -r osmea-app-config-manager.zip osmea-app-config-manager/
   ```

### Step 3: Install in WordPress

#### Method 1: Upload via WordPress Admin (Recommended)

1. **Login to WordPress Admin Panel**
   - Go to your WordPress site: `https://your-site.com/wp-admin`
   - Login with admin credentials

2. **Navigate to Plugins**
   - Click on **Plugins** in the left sidebar
   - Click **Add New** button at the top

3. **Upload Plugin**
   - Click **Upload Plugin** button at the top
   - Click **Choose File** button
   - Select the `osmea-app-config-manager.zip` file you created
   - Click **Install Now**

4. **Activate Plugin**
   - After installation, click **Activate Plugin** button

#### Method 2: Manual Installation via FTP/SFTP

1. **Extract ZIP File**
   - Extract `osmea-app-config-manager.zip` to get the folder

2. **Upload to WordPress**
   - Connect to your server via FTP/SFTP
   - Navigate to `wp-content/plugins/` directory
   - Upload the entire `osmea-app-config-manager` folder

3. **Activate in WordPress**
   - Go to WordPress Admin > Plugins
   - Find "OSMEA App Config Manager"
   - Click **Activate**

#### Method 3: Manual Installation via Command Line

```bash
# Navigate to WordPress plugins directory
cd /path/to/wordpress/wp-content/plugins/

# Copy plugin folder
cp -r /path/to/osmea-app-config-manager ./

# Set proper permissions (if needed)
chmod -R 755 osmea-app-config-manager/
```

Then activate from WordPress Admin > Plugins

### Step 4: Configure the Plugin

1. **Access Settings**
   - Go to **Settings > OSMEA App Config** in WordPress admin

2. **Edit Configuration**
   - The default configuration from `default-config.json` will be loaded
   - Edit the JSON configuration as needed
   - Click **Format JSON** to format it properly
   - Click **Save Configuration**

3. **Test REST API**
   - Open browser and go to:
     ```
     https://your-site.com/wp-json/osmea/v1/app-config
     ```
   - You should see the JSON configuration

## 🔗 REST API Endpoint

After installation, your REST API endpoint will be:

```
GET https://your-site.com/wp-json/osmea/v1/app-config
```

This endpoint returns the JSON configuration that your Flutter app can fetch.

## 📱 Use in Flutter App

Update your Flutter app to fetch configuration from WordPress:

```dart
// Example: Fetch config from WordPress
final response = await http.get(
  Uri.parse('https://your-site.com/wp-json/osmea/v1/app-config'),
);

if (response.statusCode == 200) {
  final config = json.decode(response.body);
  // Use config in your app
}
```

## ✅ Verification Checklist

- [ ] Plugin folder downloaded/extracted
- [ ] ZIP file created (if using upload method)
- [ ] Plugin uploaded to WordPress
- [ ] Plugin activated in WordPress
- [ ] Settings page accessible (Settings > OSMEA App Config)
- [ ] Configuration saved successfully
- [ ] REST API endpoint working (test in browser)
- [ ] JSON response is valid

## 🆘 Common Issues

### "Plugin could not be activated"
- Check PHP version (needs 7.4+)
- Check WordPress version (needs 5.0+)
- Check file permissions

### "REST API not working"
- Go to Settings > Permalinks and save (activate permalinks)
- Check .htaccess file permissions

### "Configuration not saving"
- Check database connection
- Check wp_options table permissions

## 📞 Need Help?

- Check `INSTALLATION.md` for detailed instructions
- Check `README.md` for feature documentation
- Open an issue on GitHub: https://github.com/masterfabric-mobile/osmea

